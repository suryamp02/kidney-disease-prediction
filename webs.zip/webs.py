
    # BloodPressure=request.values['BloodPressure']
    # SpecificGravity=request.values['SpecificGravity']
    # Albumin=request.values['Albumin']
    # Sugar=request.values['Sugar']
    # RedBloodCells=request.values['RedBloodCells']
    # Puscell=request.values['Puscell']
    # PusCellClumps=request.values['PusCellClumps']
    # Bacteria=request.values['Bacteria']
    # BloodGlucoseRandom=request.values['BloodGlucoseRandom']
    # BloodUrea=request.values['BloodUrea']
    # SerumCreatinine=request.values['SerumCreatinine']
    # Sodium=request.values['Sodium']
    # Pottassium=request.values['Pottassium']
    # Heamoglobin=request.values['Heamoglobin']
    # PackedCellVolume=request.values['PackedCellVolume']
    # WhiteBloodCellCount=request.values['WhiteBloodCellCount']
    # RedBloodCellcount=request.values['RedBloodCellcount']
    # Hypertension=request.values['Hypertension']
    # DiabetesMellitus=request.values['DiabetesMellitus']
    # CoronaryArteryDisease=request.values['CoronaryArteryDisease']
    # Appetite=request.values['Appetite']
    # PedalEdema=request.values['PedalEdema']
    # Anemia=request.values['Anemia']
    
    
    
    # print(Age,BloodPressure,SpecificGravity,Albumin,Sugar,RedBloodCells,
    #      Puscell,PusCellClumps,Bacteria,BloodGlucoseRandom,BloodUrea,SerumCreatinine,
    #      Sodium,Pottassium,Heamoglobin,PackedCellVolume,WhiteBloodCellCount,
    #      RedBloodCellcount,Hypertension,DiabetesMellitus,CoronaryArteryDisease,
    #      Appetite,PedalEdema,Anemia)
#if __name__=='__main__':
    #app.run()
    
    
from flask import Flask, render_template, request
import pickle
import numpy as np


model=pickle.load(open('naiveclass.pkl','rb'))
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')
@app.route('/kidny')
def kidny():
    return render_template('project.html')


@app.route('/predict', methods=['POST'])
def predict():
   try:
       if request.method == 'POST':
        Age=int(request.values['Age']) 
        BloodPressure=int(request.values['BloodPressure'])
        SpecificGravity=float(request.values['SpecificGravity'])
        Albumin=int(request.values['Albumin'])
        Sugar=int(request.values['Sugar'])
        RedBloodCells=int(request.values['RedBloodCells'])
        Puscell=int(request.values['Puscell'])
        PusCellClumps=int(request.values['PusCellClumps'])
        Bacteria=int(request.values['Bacteria'])
        BloodGlucoseRandom=int(request.values['BloodGlucoseRandom'])
        BloodUrea=int(request.values['BloodUrea'])
        SerumCreatinine=float(request.values['SerumCreatinine'])
        Sodium=int(request.values['Sodium'])
        Pottassium=float(request.values['Pottassium'])
        Heamoglobin=float(request.values['Heamoglobin'])
        PackedCellVolume=int(request.values['PackedCellVolume'])
        WhiteBloodCellCount=int(request.values['WhiteBloodCellCount'])
        RedBloodCellcount=int(request.values['RedBloodCellcount'])
        Hypertension=int(request.values['Hypertension'])
        DiabetesMellitus=int(request.values['DiabetesMellitus'])
        CoronaryArteryDisease=int(request.values['CoronaryArteryDisease'])
        Appetite=int(request.values['Appetite'])
        PedalEdema=int(request.values['PedalEdema'])
        Anemia=int(request.values['Anemia'])
        #print(type(SpecificGravity))
        print(SpecificGravity,"hhhhhhhhhhhhhhhh")
        #  li=[48,80,1.02,1,0,1,1,0,0,121,36,1.2,138,4.4,15.4,32,72,31,1,1,1,0,0,0]
        #  data=np.asarray(li)
        #  pre=model.predict(data.reshape(1,-1))[0]
        #  print(pre)
        print(type(Age))
        li=[[Age,BloodPressure,SpecificGravity,Albumin,Sugar,RedBloodCells,
            Puscell,PusCellClumps,Bacteria,BloodGlucoseRandom,BloodUrea,SerumCreatinine,
            Sodium,Pottassium,Heamoglobin,PackedCellVolume,WhiteBloodCellCount,
            RedBloodCellcount,Hypertension,DiabetesMellitus,CoronaryArteryDisease,
            Appetite,PedalEdema,Anemia]]
        #  print(li)
        # data=np.asarray(li)
        print(li)
        pre=model.predict(li)
        print("result is :",pre)
        if int(pre)==0:
            x="You have seens some problem"
        else:
            x="You are healthy"
        print(x)
            # Perform operations with the retrieved data
        return render_template("project.html",data=x)
   except Exception as e:
    print(f"An error occurred: {str(e)}")
    return render_template("project.html")

if __name__ == '__main__':
    app.run()
